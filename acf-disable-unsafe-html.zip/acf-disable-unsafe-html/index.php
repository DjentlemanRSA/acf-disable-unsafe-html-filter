<?php
/*
Plugin Name: Disable ACF unsafe HTML Filters
Description: Disables ACF unsafe HTML Filters
Version: 1.0
Author: Joshua Solomon
*/

// Activate escape_html_optin filter
add_filter( 'acf/the_field/escape_html_optin', '__return_true' );

// Activate allow_unsafe_html filter
add_filter( 'acf/the_field/allow_unsafe_html', function() {
    return true;
}, 10, 2);

add_filter( 'acf/admin/prevent_escaped_html_notice', '__return_true' );